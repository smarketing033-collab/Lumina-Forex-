# Lumina AI — Full Package (MT5 Integrated)

This package contains a prototype of the Lumina AI system:

- Frontend (single-file): `frontend/index.html` — Lumina UI using Lightweight-Charts.
- Backend: `backend/server.js` — WebSocket + REST server for demo/real MT5 feeds and history.
- MT5 EAs: `mt5_ea/Lumina_MT5_Feed.mq5` (real-time tick/candle feed) and `mt5_ea/Lumina_History_Exporter.mq5` (20-year history exporter).
- Dockerfile and package.json for backend.

## Quick start (local test)
1. Set `LUMINA_API_TOKEN` environment variable (same token used in EA inputs).
2. Start backend:
   ```
   cd backend
   npm install
   LUMINA_API_TOKEN=YOUR_TOKEN node server.js
   ```
3. Host `frontend/index.html` (GitHub Pages or open locally). Enter backend URL and API Key in the UI and connect.
4. In MT5, add backend domain to WebRequest allowed URLs, attach `Lumina_MT5_Feed.mq5` (Mode demo/real) and `Lumina_History_Exporter.mq5` for history upload.

## Notes
- This is a prototype. For production use TLS/HTTPS, persistent storage (Redis/Postgres), authentication, and scaling.
- Demo balance defaults to $10,000.
- The frontend connects to WS endpoint and subscribes to demo/real feeds.
