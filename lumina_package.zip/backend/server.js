// Minimal Lumina backend with history and demo/real feeds (prototype)
const express = require('express');
const bodyParser = require('body-parser');
const http = require('http');
const WebSocket = require('ws');

const PORT = process.env.PORT || 8080;
const API_TOKEN = process.env.LUMINA_API_TOKEN || 'CHANGE_ME_TOKEN';
const MAX_CANDLES = 10000;
const DEFAULT_DEMO_BALANCE = 10000;

const app = express();
app.use(bodyParser.json({ limit: '5mb' }));

const candles = { demo: {}, real: {} };
let demoAccount = { balance: DEFAULT_DEMO_BALANCE, equity: DEFAULT_DEMO_BALANCE, updatedAt: Date.now() };

function ensureSymbol(mode, symbol){
  if(!candles[mode]) candles[mode] = {};
  if(!candles[mode][symbol]) candles[mode][symbol] = [];
}

function verifyToken(req, res, next){
  const token = req.header('x-api-key') || req.query.api_key;
  if(!token || token !== API_TOKEN) return res.status(401).json({ error: 'Unauthorized' });
  next();
}

app.post('/mt5-feed/:mode', verifyToken, (req, res) => {
  const mode = req.params.mode;
  if(mode !== 'demo' && mode !== 'real') return res.status(400).json({ ok:false, error:'mode must be demo or real' });
  const body = req.body;
  if(!body || !body.type) return res.status(400).json({ ok:false, error:'bad payload' });

  if(body.type === 'tick'){
    broadcast(mode, JSON.stringify({ event:'tick', data: body }));
    return res.json({ ok:true });
  }

  if(body.type === 'candle'){
    const s = body.symbol;
    ensureSymbol(mode, s);
    const item = { time: body.time, open: parseFloat(body.open), high: parseFloat(body.high), low: parseFloat(body.low), close: parseFloat(body.close), volume: body.volume || 0 };
    const arr = candles[mode][s];
    if(arr.length > 0 && arr[arr.length-1].time === item.time){
      arr[arr.length-1] = item;
    } else {
      arr.push(item);
      if(arr.length > MAX_CANDLES) arr.shift();
    }
    broadcast(mode, JSON.stringify({ event:'candle', data: item, symbol: s }));
    return res.json({ ok:true });
  }

  return res.status(400).json({ ok:false, error:'unknown type' });
});

app.post('/account-update/:mode', verifyToken, (req, res) => {
  const mode = req.params.mode;
  const body = req.body;
  if(mode === 'demo'){
    demoAccount.balance = parseFloat(body.balance) || demoAccount.balance;
    demoAccount.equity = parseFloat(body.equity) || demoAccount.equity;
    demoAccount.updatedAt = Date.now();
    broadcast('demo', JSON.stringify({ event:'account', data: demoAccount }));
    return res.json({ ok:true });
  } else if(mode === 'real'){
    broadcast('real', JSON.stringify({ event:'account', data: body }));
    return res.json({ ok:true });
  }
  return res.status(400).json({ ok:false });
});

app.get('/:mode/candles', (req, res) => {
  const mode = req.params.mode;
  const symbol = req.query.symbol;
  const limit = parseInt(req.query.limit||500);
  if(!symbol) return res.status(400).json({ error:'symbol required' });
  ensureSymbol(mode, symbol);
  const arr = candles[mode][symbol] || [];
  res.json({ symbol, candles: arr.slice(-limit) });
});

app.get('/demo/balance', (req, res) => {
  if(!demoAccount || !demoAccount.balance) demoAccount = { balance: DEFAULT_DEMO_BALANCE, equity: DEFAULT_DEMO_BALANCE, updatedAt: Date.now() };
  res.json(demoAccount);
});

const server = http.createServer(app);
const wss = new WebSocket.Server({ server });

wss.on('connection', (ws, req) => {
  ws.subscribed = { mode: null, symbol: null };
  ws.on('message', (msg) => {
    try {
      const m = JSON.parse(msg);
      if(m.action === 'subscribe'){
        ws.subscribed.mode = m.mode;
        ws.subscribed.symbol = m.symbol;
        ws.send(JSON.stringify({ event:'subscribed', mode: m.mode, symbol: m.symbol }));
      }
      if(m.action === 'ping') ws.send(JSON.stringify({ event:'pong' }));
    } catch(e) {}
  });
});

function broadcast(mode, payload){
  wss.clients.forEach(c=>{
    if(c.readyState === WebSocket.OPEN){
      if(!c.subscribed || c.subscribed.mode === null || c.subscribed.mode === mode) {
        try { c.send(payload); } catch(e){ }
      }
    }
  });
}

server.listen(PORT, () => {
  console.log(`Lumina MT5 feed server running on port ${PORT}`);
});
